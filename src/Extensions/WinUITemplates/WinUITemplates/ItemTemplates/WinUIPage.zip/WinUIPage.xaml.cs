﻿using Microsoft.UI.Xaml.Controls;

namespace $rootnamespace$
{
    public partial class $safeitemname$ : Page
    {
        public $safeitemname$()
        {
            this.InitializeComponent();
        }
    }
}
