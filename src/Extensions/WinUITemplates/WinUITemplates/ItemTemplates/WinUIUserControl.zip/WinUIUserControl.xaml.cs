﻿using Microsoft.UI.Xaml.Controls;

namespace $rootnamespace$
{
    public partial class $safeitemname$ : UserControl
    {
        public $safeitemname$()
        {
            this.InitializeComponent();
        }
    }
}
