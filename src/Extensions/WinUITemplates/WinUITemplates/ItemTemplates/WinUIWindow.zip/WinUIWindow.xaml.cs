﻿using Microsoft.UI.Xaml;

namespace $rootnamespace$
{
    public partial class $safeitemname$ : Window
    {
        public $safeitemname$()
        {
            this.InitializeComponent();
        }
    }
}
